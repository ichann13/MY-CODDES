public class Calculation {

    void sum(int a, int b) {
        System.out.println(a + b);
        // add a and b
    }

    void sum(int a, int b, int c) {
        System.out.println(a + b + c);
        // add a and b and c
    }

    public static void main(String[] args) throws Exception {
        Calculation obj = new Calculation();
        obj.sum(10, 10, 10);
        obj.sum(20, 20);
        // output 30
        // output 40
    }
}
