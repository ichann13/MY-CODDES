public class dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("The dog barks");
    }

}