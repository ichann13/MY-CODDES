public class main {
    public static void main(String[] args) {
        Animal animal1 = new cat();
        Animal animal2 = new dog();

        animal1.makeSound();
        animal2.makeSound();

    }
}